app.controller('Tasks', ['$http', 'common',
	function($http, common) {
		
		console.log("Tasks controller starting");
		
		var self = this;
		self.confirm = common.confirm;
		
		self.task = {};		
		
		self.refresh = function() {
			$http.get('/db/tasks/').then(
				function(response) {
					self.tasks = response.data;
				},
				function(errResponse) {
					self.tasks = [];
				}
			);
		}
		
		self.refresh();
		
		self.insert = function() {
			console.log('ctrl.insert(), ' + self.task);
			$http.post('/db/tasks/json', self.task).then(
				function(response) {
					self.refresh();
				},
				function(errResponse) {
					console.log(JSON.stringify(errResponse));
				}
			);
		}

		self.edit = function(id = '') {
			$http.get('/db/persons').then(
				function(response) {
					self.persons = response.data;
				},
				function(errResponse) {
					self.persons = [];
				}
			);
			self.persons
			if(id) {
				$http.get('/db/tasks/' + id).then(
					function(response) {
						self.task = response.data[0];
						$("#editTask").modal();			
					},
					function(errResponse) {}
				);
			} else {
				self.task = {};
				$("#editTask").modal();
			}
		}
		
		self.editSubmit = function() {
			var taskGelded = self.task;
			delete taskGelded.manager;
			console.log('ctrl.editSubmit(), ' + taskGelded);
			if(taskGelded._id) {
				$http.put('/db/tasks/' + taskGelded._id, taskGelded).then(
					function(response) {
						self.refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
			} else {
				$http.post('/db/tasks/json', taskGelded).then(
					function(response) {
						self.refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);				
			}
			$('#editTask').modal('hide');
		}

		self.confirmRemove = function(task) {
			$('#editTask').modal('hide');
			common.confirm.text = 'Are you sure to delete a task "' + self.task.name + '" ?';
			common.confirm.action = self.remove;
			$("#confirmDialog").modal();
		}
		
		self.remove = function() {
			$("#confirmDialog").modal('hide');
			if(self.task._id) {
				$http.delete('/db/tasks/' + self.task._id).then(
					function(response) {
						self.refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
				$('#editTask').modal('hide');
			}
		}
		
	}
]);