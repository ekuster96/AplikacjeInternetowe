var app = angular.module('app', []);

app.controller('Page2Ctrl', ['$http',
	function($http) {
		
		console.log("Controller starting");
		
		var self = this;

		self.project = {};		
		
		var refresh = function() {
			console.log('ctrl.refresh()');
			$http.get('/db/projects/').then(
				function(response) {
					self.projects = response.data;
				},
				function(errResponse) {
					self.projects = [];
				}
			);
		}
		
		refresh();
		
		self.insert = function() {
			console.log('ctrl.insert(), ' + self.project);
			$http.post('/db/projects/json', self.project).then(
				function(response) {
					refresh();
				},
				function(errResponse) {
					console.log(JSON.stringify(errResponse));
				}
			);
		}

		self.edit = function(id = '') {
			console.log('ctrl.edit(' + id + ')');
			if(id) {
				$http.get('/db/projects/' + id).then(
					function(response) {
						self.project = response.data[0];
						$("#editproject").modal();			
					},
					function(errResponse) {}
				);
			} else {
				self.project = {};
				$("#editproject").modal();
			}
		}
		
		self.editSubmit = function() {
			console.log('ctrl.editSubmit(), ' + self.project);
			if(self.project._id) {
				$http.put('/db/projects/' + self.project._id, self.project).then(
					function(response) {
						refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
			} else {
				$http.post('/db/projects/json', self.project).then(
					function(response) {
						refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);				
			}
			$('#editproject').modal('hide');
		}

		self.confirmText = '';
		self.confirmAction = self.refresh;
		
		self.confirmRemove = function() {
			console.log('ctrl.confirmDelete(), ' + self.project);
			$('#editproject').modal('hide');
			self.confirmText = 'Are you sure to delete a project "' + self.project.firstName + ' ' + self.project.lastName + '" ?';
			self.confirmAction = self.remove;
			$("#confirmDialog").modal();
		}
		
		self.remove = function() {
			console.log('ctrl.remove(), ' + self.project);
			$("#confirmDialog").modal('hide');
			if(self.project._id) {
				$http.delete('/db/projects/' + self.project._id).then(
					function(response) {
						refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
				$('#editproject').modal('hide');
			}
		}
		
	}
]);