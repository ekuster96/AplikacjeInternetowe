var app = angular.module('app', []);

app.controller('Page1Ctrl', ['$http',
	function($http) {
		
		console.log("Controller starting");
		
		var self = this;

		self.person = {};		
		
		var refresh = function() {
			console.log('ctrl.refresh()');
			$http.get('/db/persons/').then(
				function(response) {
					self.persons = response.data;
				},
				function(errResponse) {
					self.persons = [];
				}
			);
		}
		
		refresh();
		
		self.insert = function() {
			console.log('ctrl.insert(), ' + self.person);
			$http.post('/db/persons/json', self.person).then(
				function(response) {
					refresh();
				},
				function(errResponse) {
					console.log(JSON.stringify(errResponse));
				}
			);
		}

		self.edit = function(id = '') {
			console.log('ctrl.edit(' + id + ')');
			if(id) {
				$http.get('/db/persons/' + id).then(
					function(response) {
						self.person = response.data[0];
						$("#editPerson").modal();			
					},
					function(errResponse) {}
				);
			} else {
				self.person = {};
				$("#editPerson").modal();
			}
		}
		
		self.editSubmit = function() {
			console.log('ctrl.editSubmit(), ' + self.person);
			if(self.person._id) {
				$http.put('/db/persons/' + self.person._id, self.person).then(
					function(response) {
						refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
			} else {
				$http.post('/db/persons/json', self.person).then(
					function(response) {
						refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);				
			}
			$('#editPerson').modal('hide');
		}

		self.confirmText = '';
		self.confirmAction = self.refresh;
		
		self.confirmRemove = function() {
			console.log('ctrl.confirmDelete(), ' + self.person);
			$('#editPerson').modal('hide');
			self.confirmText = 'Are you sure to delete a person "' + self.person.firstName + ' ' + self.person.lastName + '" ?';
			self.confirmAction = self.remove;
			$("#confirmDialog").modal();
		}
		
		self.remove = function() {
			console.log('ctrl.remove(), ' + self.person);
			$("#confirmDialog").modal('hide');
			if(self.person._id) {
				$http.delete('/db/persons/' + self.person._id).then(
					function(response) {
						refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
				$('#editPerson').modal('hide');
			}
		}
		
	}
]);