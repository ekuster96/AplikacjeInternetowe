var debugLog = false;

var dbName = 'mydb1';

if(debugLog) console.log('Initialization of \'' + dbName + '\'');

var mongojs = require('mongojs');
var db = mongojs(dbName);

var persons = db.collection('persons');
var projects = db.collection('projects');

if(debugLog) console.log('Delete collection \'persons\'');
persons.drop();

if(debugLog) console.log('Delete collection \'projects\'');
projects.drop();

personsExample = [
	{ _id : mongojs.ObjectId('000000000000000000000001'), firstName: 'Dmitrii', lastName: 'Mitroshenkov' },
	{ _id : mongojs.ObjectId('000000000000000000000002'), firstName: 'Chowdhury', lastName: 'Joy Barua' },
	{ _id : mongojs.ObjectId('000000000000000000000003'), firstName: 'Adrian', lastName: 'Gryza' },
	{ _id : mongojs.ObjectId('000000000000000000000004'), firstName: 'Myroslav', lastName: 'Dmukhivskyi' },
	{ _id : mongojs.ObjectId('000000000000000000000005'), firstName: 'Patryk', lastName: 'Dudka' },
	{ _id : mongojs.ObjectId('000000000000000000000006'), firstName: 'Igor', lastName: 'Gwiazdowski' },
	{ _id : mongojs.ObjectId('000000000000000000000007'), firstName: 'Adrian', lastName: 'Bus' }
];

var projectsExample = [
	{ _id : mongojs.ObjectId('000000000000000000000001') , name: 'ZosLic', managerId : mongojs.ObjectId('000000000000000000000003')  },
	{ _id : mongojs.ObjectId('000000000000000000000002') , name: 'PG', managerId : mongojs.ObjectId('000000000000000000000004')  },
	{ _id : mongojs.ObjectId('000000000000000000000003') , name: 'NSNN', managerId : mongojs.ObjectId('000000000000000000000002') }
	
];


if(debugLog) console.log('Creating new collection \'persons\'');
for(var i in personsExample) {
	if(debugLog) {
		console.log(JSON.stringify(personsExample[i]));
	}
	persons.insert(personsExample[i]);
}

if(debugLog) console.log('Creating new collection \'projects\'');
for(var i in projectsExample) {
	if(debugLog) {
		console.log(JSON.stringify(projectsExample[i]));
	}
	projects.insert(projectsExample[i]);
}

if(debugLog) console.log('End of initialization');